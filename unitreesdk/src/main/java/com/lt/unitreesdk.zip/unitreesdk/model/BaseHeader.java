package com.lt.unitreesdk.model;

public class BaseHeader {
    public int[] head; // 帧头
    public int fn;      // 帧序号
    public int len;     // 数据长度
    public int crc;
}
